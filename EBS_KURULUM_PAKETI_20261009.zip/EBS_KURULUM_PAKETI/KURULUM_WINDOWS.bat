@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo Python 3.11 veya uzeri bulunamadi. Python yukleyip tekrar deneyin.
    pause
    exit /b 1
)
python --version
python -m compileall -q ebs
if errorlevel 1 (
    echo EBS kaynak kontrolu basarisiz.
    pause
    exit /b 1
)
if not exist var mkdir var
if not exist var\documents mkdir var\documents
echo EBS kurulum on kontrolu tamamlandi.
call "%~dp0BASLAT_WINDOWS.bat"
