@echo off
setlocal
cd /d "%~dp0"
python --version
if errorlevel 1 exit /b 1
python -m compileall -q ebs
if errorlevel 1 exit /b 1
if not exist var\documents mkdir var\documents
echo EBS kurulum on kontrolu tamamlandi.
echo Baslatmak icin: python -m ebs.server --host 0.0.0.0 --port 8792
