@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist var mkdir var
if not exist var\documents mkdir var\documents
where python >nul 2>nul
if errorlevel 1 (
    echo Python 3.11 veya uzeri bulunamadi.
    pause
    exit /b 1
)
echo EBS Merkezi Server 8792 baslatiliyor...
echo Tarayicidan http://127.0.0.1:8792/ adresini acin.
python -m ebs.server --host 0.0.0.0 --port 8792 --db "%CD%\var\ebs.sqlite3"
if errorlevel 1 (
    echo EBS Server baslatilamadi.
    pause
    exit /b 1
)
