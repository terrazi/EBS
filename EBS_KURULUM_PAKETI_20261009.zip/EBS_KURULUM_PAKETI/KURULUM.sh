#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
python3 --version
python3 -m compileall -q ebs
mkdir -p var/documents
echo "EBS Merkezi Server 8792 baslatiliyor..."
echo "Tarayicidan http://127.0.0.1:8792/ adresini acin."
exec python3 -m ebs.server --host 0.0.0.0 --port 8792 --db "$PWD/var/ebs.sqlite3"
