#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
python3 --version
python3 -m compileall -q ebs
mkdir -p var/documents
echo "EBS kurulum on kontrolu tamamlandi. Baslatmak icin: python3 -m ebs.server --host 0.0.0.0 --port 8792"
